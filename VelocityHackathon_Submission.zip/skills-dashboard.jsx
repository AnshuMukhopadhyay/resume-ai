"use client";

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, Clock } from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  Radar,
} from "recharts";
import { useData } from "@/components/data-provider";

export function SkillsDashboard() {
  const [activeTab, setActiveTab] = useState("skills");
  const { metrics, skillsData, experienceData, radarData, ageingData, buzzwordsData, topCandidates, hasData } = useData();

  if (!hasData) {
    return (
      <section id="dashboard" className="border-b border-border bg-background px-4 py-16 sm:px-6">
        <div className="mx-auto max-w-7xl text-center">
          <h2 className="mb-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Skill Extraction & Analytics
          </h2>
          <p className="text-muted-foreground">
            Upload resumes to see AI-powered analysis instantly.
          </p>
        </div>
      </section>
    );
  }

  return (
    <section id="dashboard" className="border-b border-border bg-background px-4 py-16 sm:px-6">
      <div className="mx-auto max-w-7xl">
        <div className="mb-12 text-center">
          <h2 className="mb-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Skill Extraction & Analytics
          </h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Deep insights into candidate skills, experience levels, and competency mapping powered by AI.
          </p>
        </div>

        <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {metrics.map((metric) => (
            <Card
              key={metric.label}
              className="rounded-xl border border-border bg-card p-6"
            >
              <div className="flex items-center justify-between">
                <metric.icon className="h-5 w-5 text-muted-foreground" />
                <span className="text-xs font-medium text-accent">
                  {metric.change}
                </span>
              </div>
              <div className="mt-4">
                <div className="text-2xl font-bold text-foreground">
                  {metric.value}
                </div>
                <div className="text-sm text-muted-foreground">
                  {metric.label}
                </div>
              </div>
            </Card>
          ))}
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          <Card className="lg:col-span-2 rounded-xl border border-border bg-card p-6">
            <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
              <h3 className="text-lg font-semibold text-foreground">
                Analytics Overview
              </h3>
              <div className="flex gap-2">
                {["skills", "competencies", "ageing"].map((tab) => (
                  <Button
                    key={tab}
                    variant={activeTab === tab ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setActiveTab(tab)}
                    className={
                      activeTab === tab
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground hover:text-foreground"
                    }
                  >
                    {tab.charAt(0).toUpperCase() + tab.slice(1)}
                  </Button>
                ))}
              </div>
            </div>

            <div className="h-72">
              {activeTab === "skills" && (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={skillsData} layout="vertical">
                    <XAxis type="number" stroke="#666" fontSize={12} domain={[0, 'dataMax + 2']} />
                    <YAxis
                      type="category"
                      dataKey="skill"
                      stroke="#666"
                      fontSize={12}
                      width={120}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "var(--card)",
                        border: "1px solid var(--border)",
                        borderRadius: "8px",
                        color: "var(--foreground)",
                      }}
                    />
                    <Bar
                      dataKey="count"
                      fill="var(--chart-1)"
                      radius={[0, 4, 4, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              )}



              {activeTab === "competencies" && (
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart data={radarData}>
                    <PolarGrid stroke="#333" />
                    <PolarAngleAxis
                      dataKey="subject"
                      stroke="#666"
                      fontSize={12}
                    />
                    <Radar
                      dataKey="A"
                      stroke="var(--chart-1)"
                      fill="var(--chart-1)"
                      fillOpacity={0.3}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "var(--card)",
                        border: "1px solid var(--border)",
                        borderRadius: "8px",
                        color: "var(--foreground)",
                      }}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              )}

              {activeTab === "ageing" && (
                <div className="flex h-full w-full gap-6">
                  <div className="w-1/4 h-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={ageingData}
                          innerRadius={50}
                          outerRadius={70}
                          paddingAngle={5}
                          dataKey="value"
                          label={({ name }) => name}
                          labelLine={true}
                        >
                          {ageingData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "var(--card)",
                            border: "1px solid var(--border)",
                            borderRadius: "8px",
                            color: "var(--foreground)",
                          }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="w-2/4 h-full overflow-auto pr-2 border-x border-border/50 px-4">
                    <h4 className="font-semibold mb-3 text-sm">Ageing Breakdown</h4>
                    {ageingData.map((category) => (
                      <div key={category.name} className="mb-4">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs font-semibold" style={{ color: category.color }}>{category.name} ({category.percentage}%)</span>
                        </div>
                        <div className="text-[10px] leading-relaxed text-muted-foreground bg-secondary/50 p-2 rounded-md">
                          {category.skills && category.skills.length > 0
                            ? category.skills.join(", ")
                            : "No specific skills found"}
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="w-1/4 h-full overflow-auto">
                    <h4 className="font-semibold mb-3 text-sm">Buzzwords</h4>
                    <div className="flex flex-wrap gap-2">
                      {buzzwordsData.map((word) => (
                        <span
                          key={word}
                          className="inline-flex items-center rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-medium text-primary border border-primary/20"
                        >
                          {word}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </Card>

          <Card className="rounded-xl border border-border bg-card p-6">
            <h3 className="mb-6 text-lg font-semibold text-foreground">
              Top Candidates
            </h3>
            <div className="space-y-4">
              {topCandidates.map((candidate, index) => (
                <div
                  key={candidate.name}
                  className="flex flex-col gap-3 rounded-lg border border-border bg-secondary/30 p-4 transition-colors hover:bg-secondary/50"
                >
                  <div className="flex items-center gap-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary">
                      {index + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="truncate text-sm font-medium text-foreground">
                        {candidate.name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {candidate.role}
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-accent">
                        {candidate.score}%
                      </div>
                      <div className="text-xs text-muted-foreground">Match</div>
                    </div>
                  </div>

                  {candidate.missingSkills && candidate.missingSkills.length > 0 && (
                    <div className="mt-2 text-xs">
                      <div className="flex items-center gap-1 font-semibold text-destructive">
                        <AlertCircle className="h-3 w-3" />
                        <span>Missing Skills:</span>
                      </div>
                      <span className="text-muted-foreground">
                        {candidate.missingSkills.slice(0, 5).join(", ")}
                        {candidate.missingSkills.length > 5 && ` +${candidate.missingSkills.length - 5} more`}
                      </span>
                    </div>
                  )}

                  {candidate.skillAgeing && Object.keys(candidate.skillAgeing).length > 0 && (
                    <div className="text-xs">
                      <div className="flex items-center gap-1 font-semibold text-warning">
                        <Clock className="h-3 w-3" />
                        <span>Skill Ageing:</span>
                      </div>
                      <span className="text-muted-foreground">
                        {Object.entries(candidate.skillAgeing)
                          .filter(([_, status]) => status !== "Unknown")
                          .slice(0, 3)
                          .map(([skill, status]) => `${skill} (${status})`)
                          .join(", ")}
                      </span>
                    </div>
                  )}
                </div>
              ))}
            </div>
            <Button
              variant="outline"
              className="mt-6 w-full border-border text-foreground hover:bg-secondary bg-transparent"
              onClick={() => {
                const element = document.getElementById('candidates');
                if (element) {
                  element.scrollIntoView({ behavior: 'smooth' });
                }
              }}
            >
              View All Candidates
            </Button>
          </Card>
        </div>
      </div>
    </section>
  );
}
