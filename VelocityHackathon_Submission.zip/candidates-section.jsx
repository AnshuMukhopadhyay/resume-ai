"use client";

import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Search,
  ChevronDown,
  Mail,
  Phone,
  Globe,
  Linkedin,
  Star,
  CheckCircle,
  Clock,
  XCircle,
} from "lucide-react";

import { useData } from "@/components/data-provider";

const statusConfig = {
  shortlisted: {
    label: "Shortlisted",
    color: "bg-accent/10 text-accent",
    icon: CheckCircle,
  },
  pending: {
    label: "Pending",
    color: "bg-chart-3/10 text-chart-3",
    icon: Clock,
  },
  rejected: {
    label: "Rejected",
    color: "bg-destructive/10 text-destructive",
    icon: XCircle,
  },
};

export function CandidatesSection() {
  const { allCandidates: candidates, hasData } = useData();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [expandedDropdown, setExpandedDropdown] = useState(false);

  // Initialize selectedCandidate when data becomes available
  React.useEffect(() => {
    if (candidates.length > 0 && !selectedCandidate) {
      setSelectedCandidate(candidates[0]);
    } else if (candidates.length === 0) {
      setSelectedCandidate(null);
    }
  }, [candidates, selectedCandidate]);

  if (!hasData) {
    return (
      <section id="candidates" className="border-b border-border bg-background px-4 py-16 sm:px-6">
        <div className="mx-auto max-w-7xl text-center">
          <h2 className="mb-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Candidate Management
          </h2>
          <p className="text-muted-foreground">
            Upload resumes to unlock candidate profiles.
          </p>
        </div>
      </section>
    );
  }

  const filteredCandidates = candidates.filter((candidate) => {
    const matchesSearch =
      candidate.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      candidate.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
      candidate.skills.some((skill) =>
        skill.toLowerCase().includes(searchQuery.toLowerCase())
      );
    const matchesStatus =
      statusFilter === "all" || candidate.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getScoreColor = (score) => {
    if (score >= 90) return "text-accent";
    if (score >= 75) return "text-chart-3";
    return "text-muted-foreground";
  };

  return (
    <section id="candidates" className="border-b border-border bg-background px-4 py-16 sm:px-6">
      <div className="mx-auto max-w-7xl">
        <div className="mb-12 text-center">
          <h2 className="mb-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Candidate Management
          </h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Review, filter, and manage all candidates with AI-generated match
            scores and detailed profiles.
          </p>
        </div>

        <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search by name, role, or skills..."
              className="pl-10 bg-card border-border text-foreground placeholder:text-muted-foreground"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div className="relative">
            <button
              onClick={() => setExpandedDropdown(!expandedDropdown)}
              className="flex items-center gap-2 rounded-lg border border-border bg-card px-4 py-2 text-sm text-foreground hover:bg-secondary"
            >
              Filter by Status
              <ChevronDown
                className={`h-4 w-4 transition-transform ${expandedDropdown ? "rotate-180" : ""
                  }`}
              />
            </button>
            {expandedDropdown && (
              <div className="absolute right-0 top-full z-10 mt-2 w-40 rounded-lg border border-border bg-card py-2 shadow-lg">
                <button
                  onClick={() => {
                    setStatusFilter("all");
                    setExpandedDropdown(false);
                  }}
                  className={`w-full px-4 py-2 text-left text-sm hover:bg-secondary ${statusFilter === "all"
                    ? "text-primary"
                    : "text-foreground"
                    }`}
                >
                  All Status
                </button>
                {Object.keys(statusConfig).map((status) => (
                  <button
                    key={status}
                    onClick={() => {
                      setStatusFilter(status);
                      setExpandedDropdown(false);
                    }}
                    className={`w-full px-4 py-2 text-left text-sm hover:bg-secondary ${statusFilter === status
                      ? "text-primary"
                      : "text-foreground"
                      }`}
                  >
                    {statusConfig[status].label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-4">
            {filteredCandidates.map((candidate) => {
              const StatusIcon = statusConfig[candidate.status].icon;
              return (
                <Card
                  key={candidate.id}
                  className={`cursor-pointer rounded-xl border bg-card p-4 transition-all ${selectedCandidate?.id === candidate.id
                    ? "border-primary"
                    : "border-border hover:border-primary/50"
                    }`}
                  onClick={() => setSelectedCandidate(candidate)}
                >
                  <div className="flex items-center gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary">
                      {candidate.avatar}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="truncate text-base font-semibold text-foreground">
                          {candidate.name}
                        </h3>
                        {candidate.matchScore >= 95 && (
                          <Star className="h-4 w-4 fill-chart-3 text-chart-3" />
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {candidate.role}
                      </p>
                      <div className="mt-2 flex flex-wrap gap-1">
                        {candidate.skills.slice(0, 3).map((skill) => (
                          <span
                            key={skill}
                            className="rounded bg-secondary px-2 py-0.5 text-xs text-secondary-foreground"
                          >
                            {skill}
                          </span>
                        ))}
                        {candidate.skills.length > 3 && (
                          <span className="rounded bg-secondary px-2 py-0.5 text-xs text-muted-foreground">
                            +{candidate.skills.length - 3}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <div
                        className={`text-xl font-bold ${getScoreColor(
                          candidate.matchScore
                        )}`}
                      >
                        {candidate.matchScore}%
                      </div>
                      <div
                        className={`mt-1 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium ${statusConfig[candidate.status].color
                          }`}
                      >
                        <StatusIcon className="h-3 w-3" />
                        {statusConfig[candidate.status].label}
                      </div>
                    </div>
                  </div>
                </Card>
              );
            })}

            {filteredCandidates.length === 0 && (
              <Card className="flex min-h-40 items-center justify-center rounded-xl border border-border bg-card p-8">
                <p className="text-muted-foreground">
                  No candidates found matching your criteria.
                </p>
              </Card>
            )}
          </div>

          <Card className="sticky top-24 h-fit rounded-xl border border-border bg-card p-6">
            {selectedCandidate ? (
              <>
                <div className="mb-6 flex items-center gap-4">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-lg font-bold text-primary">
                    {selectedCandidate.avatar}
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-foreground">
                      {selectedCandidate.name}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {selectedCandidate.role}
                    </p>
                  </div>
                </div>

                <div className="mb-6 rounded-lg bg-secondary/50 p-4">
                  <div className="mb-2 flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">
                      Match Score
                    </span>
                    <span
                      className={`text-xl font-bold ${getScoreColor(
                        selectedCandidate.matchScore
                      )}`}
                    >
                      {selectedCandidate.matchScore}%
                    </span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-secondary">
                    <div
                      className="h-full rounded-full bg-primary transition-all"
                      style={{ width: `${selectedCandidate.matchScore}%` }}
                    />
                  </div>
                </div>

                <div className="mb-6 space-y-3">
                  <div className="flex items-center gap-3 text-sm">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span className="text-foreground">
                      {selectedCandidate.email}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span className="text-foreground">
                      {selectedCandidate.phone}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <Globe className="h-4 w-4 text-muted-foreground" />
                    <span className="text-foreground">
                      {selectedCandidate.location}
                    </span>
                  </div>
                </div>

                <div className="mb-6">
                  <h4 className="mb-2 text-sm font-medium text-foreground">
                    Skills ({selectedCandidate.skills.length})
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedCandidate.skills.map((skill) => (
                      <span
                        key={skill}
                        className="rounded-md bg-primary/10 px-2 py-1 text-xs text-primary"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mb-6">
                  <h4 className="mb-2 text-sm font-medium text-foreground">
                    Experience
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    {selectedCandidate.experience} of professional experience
                  </p>
                </div>

                <div className="flex gap-3">
                  <Button className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90">
                    Contact
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    className="border-border text-foreground hover:bg-secondary bg-transparent"
                  >
                    <Linkedin className="h-4 w-4" />
                  </Button>
                </div>
              </>
            ) : (
              <div className="flex min-h-64 flex-col items-center justify-center text-center">
                <p className="text-muted-foreground">
                  Select a candidate to view their full profile.
                </p>
              </div>
            )}
          </Card>
        </div>
      </div>
    </section>
  );
}
