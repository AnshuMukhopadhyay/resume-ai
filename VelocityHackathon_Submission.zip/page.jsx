"use client";
import React, { useState } from "react";

import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { resetAnalytics } from "@/lib/analytics";
import { useData } from "@/components/data-provider";
import { Sparkles } from "lucide-react";

export default function SignInForm() {
  const router = useRouter();


  const { resetData, setUserRole } = useData();
  const [role, setRole] = useState("student");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  function handleSignIn() {
    if (password !== "password123") {
      setError("Incorrect password. Try 'password123'");
      return;
    }

    localStorage.clear();
    localStorage.setItem("user", "signed-in");
    resetData();
    setUserRole(role);
    resetAnalytics();

    // Redirect based on role not strictly necessary if home handles visibility, 
    // but good for UX if pages differed. For now both go to /.
    router.push("/");
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50 p-4">
      <div className="w-full max-w-[400px] rounded-2xl border border-gray-200 bg-white p-10 shadow-sm">
        <div className="mb-8 text-center">
          <div className="mb-6 flex justify-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              <Sparkles className="h-6 w-6 text-primary" />
            </div>
          </div>
          <h1 className="text-2xl font-medium text-gray-900">Sign in</h1>
          <p className="mt-2 text-base text-gray-600">to continue to ResumeAI</p>
        </div>

        <div className="mb-6 flex rounded-lg bg-gray-100 p-1">
          <button
            onClick={() => setRole("student")}
            className={`flex-1 rounded-md px-4 py-2 text-sm font-medium transition-colors ${role === "student"
              ? "bg-white text-gray-900 shadow-sm"
              : "text-gray-500 hover:text-gray-900"
              }`}
          >
            Student
          </button>
          <button
            onClick={() => setRole("recruiter")}
            className={`flex-1 rounded-md px-4 py-2 text-sm font-medium transition-colors ${role === "recruiter"
              ? "bg-white text-gray-900 shadow-sm"
              : "text-gray-500 hover:text-gray-900"
              }`}
          >
            Recruiter
          </button>
        </div>

        <div className="space-y-6">
          <div className="space-y-4">
            <input
              type="text"
              className="w-full rounded border border-gray-300 px-3 py-3 text-base text-gray-900 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              placeholder={role === "student" ? "Student Email or Phone" : "Recruiter Email or ID"}
            />

            <input
              type="password"
              className="w-full rounded border border-gray-300 px-3 py-3 text-base text-gray-900 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setError("");
              }}
              onKeyDown={(e) => e.key === "Enter" && handleSignIn()}
            />
            {error && <p className="text-sm text-red-500">{error}</p>}

            <div className="text-sm font-medium text-blue-600 hover:text-blue-700 cursor-pointer">
              Forgot password?
            </div>
          </div>

          <div className="text-sm text-gray-600">
            Not your computer? Use Guest mode to sign in privately. <span className="font-medium text-blue-600 hover:text-blue-700 cursor-pointer">Learn more</span>
          </div>

          <div className="flex items-center justify-between pt-4">
            <button
              onClick={() => router.push("/sign-up")}
              className="text-sm font-medium text-blue-600 hover:text-blue-700"
            >
              Create account
            </button>
            <Button
              onClick={handleSignIn}
              className="rounded-full bg-[#0b57d0] px-6 py-2 font-medium text-white hover:bg-[#0b57d0]/90 hover:shadow-md"
            >
              Sign In
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
