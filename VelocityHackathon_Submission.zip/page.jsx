"use client";
import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";

export default function SignUpForm() {
    const router = useRouter();
    const [role, setRole] = useState("student");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [error, setError] = useState("");

    function handleSignUp() {
        if (password !== confirmPassword) {
            setError("Passwords do not match");
            return;
        }
        if (password.length < 4) {
            setError("Password must be at least 4 characters");
            return;
        }

        // Simulate account creation
        localStorage.setItem("user", "signed-in");
        // In a real app, we'd send data to backend here
        router.push("/");
    }

    return (
        <div className="flex min-h-screen items-center justify-center bg-gray-50 p-4">
            <div className="w-full max-w-[400px] rounded-2xl border border-gray-200 bg-white p-10 shadow-sm">
                <div className="mb-8 text-center">
                    <div className="mb-6 flex justify-center">
                        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                            <Sparkles className="h-6 w-6 text-primary" />
                        </div>
                    </div>
                    <h1 className="text-2xl font-medium text-gray-900">Create Account</h1>
                    <p className="mt-2 text-base text-gray-600">Join ResumeAI today</p>
                </div>

                <div className="mb-6 flex rounded-lg bg-gray-100 p-1">
                    <button
                        onClick={() => setRole("student")}
                        className={`flex-1 rounded-md px-4 py-2 text-sm font-medium transition-colors ${role === "student"
                            ? "bg-white text-gray-900 shadow-sm"
                            : "text-gray-500 hover:text-gray-900"
                            }`}
                    >
                        Student
                    </button>
                    <button
                        onClick={() => setRole("recruiter")}
                        className={`flex-1 rounded-md px-4 py-2 text-sm font-medium transition-colors ${role === "recruiter"
                            ? "bg-white text-gray-900 shadow-sm"
                            : "text-gray-500 hover:text-gray-900"
                            }`}
                    >
                        Recruiter
                    </button>
                </div>

                <div className="space-y-6">
                    <div className="space-y-4">
                        <input
                            type="text"
                            className="w-full rounded border border-gray-300 px-3 py-3 text-base text-gray-900 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                            placeholder={role === "student" ? "Student Email" : "Recruiter Email"}
                        />

                        <input
                            type="password"
                            className="w-full rounded border border-gray-300 px-3 py-3 text-base text-gray-900 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                            placeholder="Password"
                            value={password}
                            onChange={(e) => {
                                setPassword(e.target.value);
                                setError("");
                            }}
                        />

                        <input
                            type="password"
                            className="w-full rounded border border-gray-300 px-3 py-3 text-base text-gray-900 outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                            placeholder="Confirm Password"
                            value={confirmPassword}
                            onChange={(e) => {
                                setConfirmPassword(e.target.value);
                                setError("");
                            }}
                            onKeyDown={(e) => e.key === "Enter" && handleSignUp()}
                        />

                        {error && <p className="text-sm text-red-500">{error}</p>}
                    </div>

                    <div className="flex items-center justify-between pt-4">
                        <button
                            onClick={() => router.push("/sign-in")}
                            className="text-sm font-medium text-blue-600 hover:text-blue-700"
                        >
                            Sign in instead
                        </button>
                        <Button
                            onClick={handleSignUp}
                            className="rounded-full bg-[#0b57d0] px-6 py-2 font-medium text-white hover:bg-[#0b57d0]/90 hover:shadow-md"
                        >
                            Sign Up
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    );
}
