"use client";

import React, { createContext, useContext, useState, useCallback } from "react";
import { TrendingUp, Users, Award, Target } from "lucide-react";

const DataContext = createContext(null);

const DEFAULT_METRICS = [
  {
    label: "Total Candidates",
    value: "0",
    change: "0%",
    icon: Users,
  },
  {
    label: "Average Match Score",
    value: "0%",
    change: "0%",
    icon: Target,
  },
  {
    label: "Skills Extracted",
    value: "0",
    change: "0%",
    icon: Award,
  },
  {
    label: "Successful Matches",
    value: "0",
    change: "0%",
    icon: TrendingUp,
  },
];

const SIMULATED_METRICS = [
  {
    label: "Total Candidates",
    value: "1,284",
    change: "+12%",
    icon: Users,
  },
  {
    label: "Average Match Score",
    value: "78%",
    change: "+5%",
    icon: Target,
  },
  {
    label: "Skills Extracted",
    value: "4,521",
    change: "+18%",
    icon: Award,
  },
  {
    label: "Successful Matches",
    value: "342",
    change: "+23%",
    icon: TrendingUp,
  },
];

const SIMULATED_SKILLS_DATA = [
  { skill: "React", count: 85, level: 92 },
  { skill: "Python", count: 78, level: 88 },
  { skill: "TypeScript", count: 72, level: 85 },
  { skill: "Node.js", count: 65, level: 80 },
  { skill: "SQL", count: 58, level: 75 },
  { skill: "AWS", count: 45, level: 70 },
];

const SIMULATED_EXPERIENCE_DATA = [
  { name: "0-2 years", value: 25, color: "var(--chart-1)" },
  { name: "2-5 years", value: 40, color: "var(--chart-2)" },
  { name: "5-10 years", value: 25, color: "var(--chart-3)" },
  { name: "10+ years", value: 10, color: "var(--chart-4)" },
];

const SIMULATED_RADAR_DATA = [
  { subject: "Technical", A: 92, fullMark: 100 },
  { subject: "Communication", A: 78, fullMark: 100 },
  { subject: "Leadership", A: 65, fullMark: 100 },
  { subject: "Problem Solving", A: 88, fullMark: 100 },
  { subject: "Teamwork", A: 82, fullMark: 100 },
  { subject: "Creativity", A: 70, fullMark: 100 },
  { subject: "Creativity", A: 70, fullMark: 100 },
];

const SIMULATED_AGEING_DATA = [
  { name: "Growing", value: 45, color: "var(--chart-1)", skills: ["Python", "Machine Learning", "React", "Cloud Computing"], percentage: 45 },
  { name: "Stable", value: 30, color: "var(--chart-2)", skills: ["Java", "SQL", "Project Management", "Communication"], percentage: 30 },
  { name: "Declining", value: 10, color: "var(--destructive)", skills: ["Flash", "Mainframe", "Legacy Systems"], percentage: 10 },
];

const SIMULATED_TOP_CANDIDATES = [
  {
    name: "Sarah Chen",
    role: "Senior Developer",
    score: 98,
    skills: ["React", "TypeScript", "Node.js"],
  },
  {
    name: "Marcus Johnson",
    role: "Full Stack Engineer",
    score: 95,
    skills: ["Python", "Django", "AWS"],
  },
  {
    name: "Emily Rodriguez",
    role: "Frontend Lead",
    score: 93,
    skills: ["React", "Vue.js", "CSS"],
  },
  {
    name: "David Kim",
    role: "Backend Developer",
    score: 91,
    skills: ["Java", "Spring", "PostgreSQL"],
  },
];

const POTENTIAL_SKILLS = [
  "React", "TypeScript", "Node.js", "Python", "AWS", "Docker", "Kubernetes",
  "GraphQL", "MongoDB", "PostgreSQL", "Java", "Spring Boot", "Go", "Rust",
  "Vue.js", "Angular", "Svelte", "Next.js", "Tailwind CSS", "Figma"
];

const ROLES = [
  "Frontend Developer", "Backend Developer", "Full Stack Engineer",
  "DevOps Engineer", "Product Designer", "Data Scientist", "System Architect"
];

const LOCATIONS = ["San Francisco, CA", "New York, NY", "Austin, TX", "Remote", "London, UK", "Berlin, DE"];

function generateCandidate(filename) {
  // Simple "hash" to get semi-consistent random results for a filename, or just random
  // For this, we'll just use random to be more "dynamic" feeling
  const name = filename.replace(/\.(pdf|docx?)$/i, "").replace(/[-_]/g, " ");
  const role = ROLES[Math.floor(Math.random() * ROLES.length)];
  const score = Math.floor(Math.random() * 30) + 70; // 70-100

  // Pick 3-6 random skills
  const numSkills = Math.floor(Math.random() * 4) + 3;
  const skills = [];
  const skillPool = [...POTENTIAL_SKILLS];
  for (let i = 0; i < numSkills; i++) {
    const idx = Math.floor(Math.random() * skillPool.length);
    skills.push(skillPool.splice(idx, 1)[0]);
  }

  return {
    id: Math.random().toString(36).substr(2, 9),
    name: name,
    role: role,
    email: `${name.toLowerCase().replace(/\s+/g, ".")}@example.com`,
    phone: `+1 (555) ${Math.floor(Math.random() * 900) + 100}-${Math.floor(Math.random() * 9000) + 1000}`,
    location: LOCATIONS[Math.floor(Math.random() * LOCATIONS.length)],
    experience: `${Math.floor(Math.random() * 10) + 1} years`,
    matchScore: score,
    skills: skills,
    status: score > 90 ? "shortlisted" : "pending",
    avatar: name.split(" ").map(n => n[0]).join("").toUpperCase().substring(0, 2),
  };
}

export function DataProvider({ children }) {
  const [hasData, setHasData] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [candidates, setCandidates] = useState([]);
  const [userRole, setUserRole] = useState("student"); // 'student' or 'recruiter'

  const resetData = useCallback(() => {
    setHasData(false);
    setUploadedFiles([]);
    setCandidates([]);
    // userRole is persistent for the session usually, but let's keep it 'student' default or allow reset if needed. 
    // actually, let's NOT reset userRole here, as it's set during sign-in.
  }, []);

  const simulateAnalysis = useCallback((file, realResult = null) => {
    // Generate a candidate profile for this specific file, potentially using real data
    let newCandidate;

    if (realResult) {
      // Map backend result to candidate structure
      const name = file.name.replace(/\.(pdf|docx?)$/i, "").replace(/[-_]/g, " ");
      newCandidate = {
        id: Math.random().toString(36).substr(2, 9),
        name: name,
        role: realResult.best_role || "Unknown Role",
        email: `${name.toLowerCase().replace(/\s+/g, ".")}@example.com`,
        phone: `+1 (555) ${Math.floor(Math.random() * 900) + 100}-${Math.floor(Math.random() * 9000) + 1000}`,
        location: LOCATIONS[Math.floor(Math.random() * LOCATIONS.length)],
        experience: realResult.experience || `${Math.floor(Math.random() * 10) + 1} years`, // Backend doesn't seem to return experience yet?
        matchScore: realResult.skill_match_score || realResult.confidence_percent || 0,
        skills: (realResult.strengths && realResult.strengths.length > 0) ? realResult.strengths : ["Communication", "Problem Solving", "Teamwork"],
        status: (realResult.skill_match_score > 80 || realResult.confidence_percent > 80) ? "shortlisted" : "pending",
        avatar: name.split(" ").map(n => n[0]).join("").toUpperCase().substring(0, 2),
        missingSkills: realResult.missing_skills || [],
        skillAgeing: realResult.skill_ageing || {},
        roleScores: realResult.role_scores || {}
      };
    } else {
      // Fallback or purely simulated
      newCandidate = generateCandidate(file.name);
    }

    setCandidates(prev => {
      const newCandidates = [...prev, newCandidate];
      // Sort by match score descending
      return newCandidates.sort((a, b) => b.matchScore - a.matchScore);
    });
    setHasData(true);
  }, []);

  const addFile = useCallback((file) => {
    setUploadedFiles((prev) => [...prev, file]);
  }, []);

  const updateFileStatus = useCallback((fileName, status, score) => {
    setUploadedFiles((prev) =>
      prev.map((f) =>
        f.name === fileName ? { ...f, status, score } : f
      )
    );
  }, []);

  const removeFile = useCallback((fileName) => {
    setUploadedFiles((prev) => prev.filter((f) => f.name !== fileName));
    // Also remove the candidate generated from this file (approximate match by name)
    const nameFromStats = fileName.replace(/\.(pdf|docx?)$/i, "").replace(/[-_]/g, " ");
    setCandidates(prev => prev.filter(c => c.name !== nameFromStats));
  }, []);

  // Derived Analytics
  const metrics = React.useMemo(() => {
    if (candidates.length === 0) return DEFAULT_METRICS;

    const avgScore = Math.round(candidates.reduce((acc, c) => acc + c.matchScore, 0) / candidates.length);
    const totalSkills = candidates.reduce((acc, c) => acc + c.skills.length, 0);
    const successful = candidates.filter(c => c.status === 'shortlisted').length;

    return [
      { label: "Total Candidates", value: candidates.length.toString(), change: "+1", icon: Users },
      { label: "Average Match Score", value: `${avgScore}%`, change: "+2%", icon: Target },
      { label: "Skills Extracted", value: totalSkills.toString(), change: `+${Math.floor(Math.random() * 10)}`, icon: Award },
      { label: "Successful Matches", value: successful.toString(), change: "0%", icon: TrendingUp },
    ];
  }, [candidates]);

  const skillsData = React.useMemo(() => {
    const counts = {};
    candidates.forEach(c => {
      c.skills.forEach(s => {
        counts[s] = (counts[s] || 0) + 1;
      });
    });

    // Add variance for single candidate to avoid equal bars
    const isSingle = candidates.length === 1;

    return Object.entries(counts)
      .map(([skill, count]) => {
        // If single candidate, simulate a relevance score between 70-100 based on string hash or random seeded
        // Using a simple hash for consistency
        const variety = isSingle ? (skill.length * 7 % 30) + 70 : count;
        return {
          skill,
          count: variety,
          level: isSingle ? variety : Math.round((count / candidates.length) * 100)
        };
      })
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }, [candidates]);

  const ageingData = React.useMemo(() => {
    if (candidates.length === 0) return SIMULATED_AGEING_DATA;

    const details = { Growing: [], Stable: [], Declining: [] };
    const counts = { Growing: 0, Stable: 0, Declining: 0 };

    const mapStatus = (status) => {
      if (!status) return "Stable";
      const s = status.toLowerCase();
      if (["growing", "fresh", "booming", "trending", "rising", "high demand", "high"].includes(s)) return "Growing";
      if (["stable", "constant", "steady", "standard", "medium"].includes(s)) return "Stable";
      if (["declining", "decaying", "obsolete", "legacy", "falling", "low demand", "low"].includes(s)) return "Declining";
      return "Stable";
    };

    candidates.forEach(c => {
      if (c.skillAgeing) {
        Object.entries(c.skillAgeing).forEach(([skill, status]) => {
          if (status === "Unknown") return;
          const category = mapStatus(status);
          counts[category]++;
          if (!details[category].includes(skill)) details[category].push(skill);
        });
      }
    });

    const total = Object.values(counts).reduce((a, b) => a + b, 0);

    // If we have NO data from any candidate, return simulated
    if (total === 0) return SIMULATED_AGEING_DATA;

    const result = [
      { name: "Growing", value: counts.Growing, color: "var(--chart-1)", skills: details.Growing, percentage: Math.round((counts.Growing / total) * 100) },
      { name: "Stable", value: counts.Stable, color: "var(--chart-2)", skills: details.Stable, percentage: Math.round((counts.Stable / total) * 100) },
      { name: "Declining", value: counts.Declining, color: "var(--destructive)", skills: details.Declining, percentage: Math.round((counts.Declining / total) * 100) },
    ].filter(d => d.value > 0);

    return result;
  }, [candidates]);

  const radarData = React.useMemo(() => {
    if (candidates.length === 0) return hasData ? [] : SIMULATED_RADAR_DATA;

    // Aggregate scores per role across all candidates
    const roleAgg = {};
    candidates.forEach(c => {
      if (c.roleScores) {
        Object.entries(c.roleScores).forEach(([role, score]) => {
          if (!roleAgg[role]) roleAgg[role] = { total: 0, count: 0 };
          roleAgg[role].total += score;
          roleAgg[role].count += 1;
        });
      }
    });

    const data = Object.entries(roleAgg).map(([role, { total, count }]) => ({
      subject: role,
      A: Math.round(total / count), // Average score
      fullMark: 100
    }));

    // Return top 6 roles by average score
    return data.sort((a, b) => b.A - a.A).slice(0, 6);
  }, [candidates, hasData]);

  const buzzwordsData = React.useMemo(() => {
    if (candidates.length === 0) return ["AI Integration", "Cloud Architecture", "Scalability", "Microservices"];

    // Use strengths from the last/top candidate for context or aggregate
    const allBuzzwords = new Set();
    candidates.forEach(c => {
      if (c.skills) c.skills.forEach(s => allBuzzwords.add(s));
    });
    return Array.from(allBuzzwords).slice(0, 15);
  }, [candidates]);

  const value = {
    hasData: candidates.length > 0,
    uploadedFiles,
    resetData,
    simulateAnalysis,
    addFile,
    updateFileStatus,
    removeFile,
    metrics,
    skillsData,
    experienceData: hasData ? SIMULATED_EXPERIENCE_DATA : [],
    radarData,
    ageingData,
    buzzwordsData,
    topCandidates: candidates.map(c => ({
      ...c,
      score: c.matchScore || c.score || 0 // Normalize score
    })).slice(0, 4),
    allCandidates: candidates,
    userRole,
    setUserRole,
  };

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
}

export function useData() {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error("useData must be used within a DataProvider");
  }
  return context;
}
