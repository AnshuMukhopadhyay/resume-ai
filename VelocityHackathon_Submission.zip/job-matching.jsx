"use client";

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Briefcase,
  MapPin,
  Clock,
  DollarSign,
  ChevronRight,
  Search,
  Filter,
  Star,
  Users,
} from "lucide-react";

const jobListings = [
  {
    id: 1,
    title: "Senior Frontend Developer",
    company: "TechCorp Inc.",
    location: "San Francisco, CA",
    type: "Full-time",
    salary: "$150k - $180k",
    matchScore: 96,
    requiredSkills: ["React", "TypeScript", "GraphQL"],
    matchedCandidates: 24,
    posted: "2 days ago",
  },
  {
    id: 2,
    title: "Full Stack Engineer",
    company: "StartupXYZ",
    location: "Remote",
    type: "Full-time",
    salary: "$120k - $150k",
    matchScore: 89,
    requiredSkills: ["Node.js", "React", "PostgreSQL"],
    matchedCandidates: 18,
    posted: "5 days ago",
  },
  {
    id: 3,
    title: "Python Backend Developer",
    company: "DataFlow Systems",
    location: "New York, NY",
    type: "Full-time",
    salary: "$130k - $160k",
    matchScore: 85,
    requiredSkills: ["Python", "Django", "AWS"],
    matchedCandidates: 31,
    posted: "1 week ago",
  },
  {
    id: 4,
    title: "DevOps Engineer",
    company: "CloudNine",
    location: "Austin, TX",
    type: "Contract",
    salary: "$90/hr",
    matchScore: 78,
    requiredSkills: ["Kubernetes", "Docker", "Terraform"],
    matchedCandidates: 12,
    posted: "3 days ago",
  },
];

const filters = [
  { label: "Remote", active: false },
  { label: "Full-time", active: true },
  { label: "$100k+", active: false },
  { label: "Senior", active: false },
];

export function JobMatching() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilters, setActiveFilters] = useState(filters);
  const [selectedJob, setSelectedJob] = useState(null);

  const toggleFilter = (index) => {
    setActiveFilters((prev) =>
      prev.map((f, i) => (i === index ? { ...f, active: !f.active } : f))
    );
  };

  const getScoreColor = (score) => {
    if (score >= 90) return "text-accent";
    if (score >= 75) return "text-chart-3";
    return "text-muted-foreground";
  };

  return (
    <section id="matching" className="border-b border-border bg-background px-4 py-16 sm:px-6">
      <div className="mx-auto max-w-7xl">
        <div className="mb-12 text-center">
          <h2 className="mb-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            AI-Powered Job Matching
          </h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Our AI analyzes job requirements and candidate profiles to find the
            perfect match with precision scoring.
          </p>
        </div>

        <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search jobs, skills, or companies..."
              className="pl-10 bg-card border-border text-foreground placeholder:text-muted-foreground"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            {activeFilters.map((filter, index) => (
              <button
                key={filter.label}
                onClick={() => toggleFilter(index)}
                className={`rounded-full px-3 py-1 text-xs font-medium transition-colors ${
                  filter.active
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                }`}
              >
                {filter.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <div className="space-y-4">
            {jobListings.map((job) => (
              <Card
                key={job.id}
                className={`cursor-pointer rounded-xl border bg-card p-6 transition-all ${
                  selectedJob === job.id
                    ? "border-primary"
                    : "border-border hover:border-primary/50"
                }`}
                onClick={() => setSelectedJob(job.id)}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="mb-2 flex items-center gap-2">
                      <h3 className="text-lg font-semibold text-foreground">
                        {job.title}
                      </h3>
                      {job.matchScore >= 90 && (
                        <Star className="h-4 w-4 fill-chart-3 text-chart-3" />
                      )}
                    </div>
                    <p className="mb-3 text-sm text-muted-foreground">
                      {job.company}
                    </p>

                    <div className="mb-4 flex flex-wrap gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        {job.location}
                      </span>
                      <span className="flex items-center gap-1">
                        <Briefcase className="h-3 w-3" />
                        {job.type}
                      </span>
                      <span className="flex items-center gap-1">
                        <DollarSign className="h-3 w-3" />
                        {job.salary}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {job.posted}
                      </span>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {job.requiredSkills.map((skill) => (
                        <span
                          key={skill}
                          className="rounded-md bg-secondary px-2 py-1 text-xs text-secondary-foreground"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="text-right">
                    <div
                      className={`text-2xl font-bold ${getScoreColor(
                        job.matchScore
                      )}`}
                    >
                      {job.matchScore}%
                    </div>
                    <div className="text-xs text-muted-foreground">Match</div>
                    <div className="mt-2 flex items-center gap-1 text-xs text-muted-foreground">
                      <Users className="h-3 w-3" />
                      {job.matchedCandidates} candidates
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          <Card className="sticky top-24 h-fit rounded-xl border border-border bg-card p-6">
            {selectedJob ? (
              <>
                {(() => {
                  const job = jobListings.find((j) => j.id === selectedJob);
                  if (!job) return null;
                  return (
                    <>
                      <div className="mb-6">
                        <h3 className="mb-2 text-xl font-bold text-foreground">
                          {job.title}
                        </h3>
                        <p className="text-muted-foreground">{job.company}</p>
                      </div>

                      <div className="mb-6 rounded-lg bg-secondary/50 p-4">
                        <div className="mb-2 flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">
                            AI Match Score
                          </span>
                          <span
                            className={`text-xl font-bold ${getScoreColor(
                              job.matchScore
                            )}`}
                          >
                            {job.matchScore}%
                          </span>
                        </div>
                        <div className="h-2 overflow-hidden rounded-full bg-secondary">
                          <div
                            className="h-full rounded-full bg-primary transition-all"
                            style={{ width: `${job.matchScore}%` }}
                          />
                        </div>
                      </div>

                      <div className="mb-6 space-y-4">
                        <div>
                          <h4 className="mb-2 text-sm font-medium text-foreground">
                            Required Skills
                          </h4>
                          <div className="flex flex-wrap gap-2">
                            {job.requiredSkills.map((skill) => (
                              <span
                                key={skill}
                                className="rounded-md bg-primary/10 px-2 py-1 text-xs text-primary"
                              >
                                {skill}
                              </span>
                            ))}
                          </div>
                        </div>

                        <div>
                          <h4 className="mb-2 text-sm font-medium text-foreground">
                            Job Details
                          </h4>
                          <div className="space-y-2 text-sm text-muted-foreground">
                            <div className="flex items-center gap-2">
                              <MapPin className="h-4 w-4" />
                              {job.location}
                            </div>
                            <div className="flex items-center gap-2">
                              <DollarSign className="h-4 w-4" />
                              {job.salary}
                            </div>
                            <div className="flex items-center gap-2">
                              <Briefcase className="h-4 w-4" />
                              {job.type}
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="flex gap-3">
                        <Button className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90">
                          View Matches
                          <ChevronRight className="ml-1 h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          className="border-border text-foreground hover:bg-secondary bg-transparent"
                        >
                          Edit Job
                        </Button>
                      </div>
                    </>
                  );
                })()}
              </>
            ) : (
              <div className="flex min-h-64 flex-col items-center justify-center text-center">
                <Briefcase className="mb-4 h-12 w-12 text-muted-foreground/50" />
                <p className="text-muted-foreground">
                  Select a job listing to view details and matching candidates.
                </p>
              </div>
            )}
          </Card>
        </div>
      </div>
    </section>
  );
}
