export type AnalyticsState = {
  totalCandidates: number;
  avgMatchScore: number;
  aiMatchScore: number;
  resumesProcessed: number;
};

export const EMPTY_ANALYTICS: AnalyticsState = {
  totalCandidates: 0,
  avgMatchScore: 0,
  aiMatchScore: 0,
  resumesProcessed: 0,
};

export function resetAnalytics() {
  if (typeof window === "undefined") return;
  localStorage.setItem("analytics", JSON.stringify(EMPTY_ANALYTICS));
}

export function getAnalytics(): AnalyticsState {
  if (typeof window === "undefined") return EMPTY_ANALYTICS;

  const data = localStorage.getItem("analytics");
  return data ? JSON.parse(data) : EMPTY_ANALYTICS;
}

export function updateAnalytics(
  partial: Partial<AnalyticsState>
) {
  const current = getAnalytics();
  const updated = { ...current, ...partial };
  localStorage.setItem("analytics", JSON.stringify(updated));
}
