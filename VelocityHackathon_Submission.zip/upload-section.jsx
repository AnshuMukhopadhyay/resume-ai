"use client";

import React, { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Upload,
  FileText,
  CheckCircle,
  Loader2,
  X,
  Sparkles,
} from "lucide-react";
import { useData } from "@/components/data-provider";

export function UploadSection() {
  const [isDragOver, setIsDragOver] = useState(false);
  const { uploadedFiles, addFile, updateFileStatus, removeFile, simulateAnalysis, userRole } = useData();

  if (userRole === "recruiter") {
    return null;
  }

  const uploadFile = useCallback(async (file) => {
    const newFile = {
      name: file.name,
      size: file.size,
      status: "uploading",
    };

    addFile(newFile);

    const formData = new FormData();
    formData.append("file", file);

    try {
      updateFileStatus(file.name, "analyzing");

      const response = await fetch("http://localhost:5555/analyze-resume", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Analysis failed");
      }

      const result = await response.json();

      // result contains: { best_role, confidence_percent, status, strengths, missing_skills, ... }
      updateFileStatus(file.name, "complete", result.skill_match_score || Math.round(result.confidence_percent));
      simulateAnalysis(newFile, result); // Handle the real result

    } catch (error) {
      console.error("Upload error:", error);
      updateFileStatus(file.name, "error");
    }
  }, [addFile, updateFileStatus, simulateAnalysis]);

  const handleDrop = useCallback(
    (e) => {
      e.preventDefault();
      setIsDragOver(false);

      const droppedFiles = Array.from(e.dataTransfer.files);
      droppedFiles.forEach((file) => {
        if (file.type === "application/pdf" || file.name.endsWith(".pdf")) {
          uploadFile(file);
        }
      });
    },
    [uploadFile]
  );

  const handleFileSelect = useCallback(
    (e) => {
      const selectedFiles = Array.from(e.target.files || []);
      selectedFiles.forEach((file) => {
        uploadFile(file);
      });
    },
    [uploadFile]
  );

  const formatSize = (bytes) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <section id="upload" className="border-b border-border bg-background px-4 py-16 sm:px-6">
      <div className="mx-auto max-w-7xl">
        <div className="mb-12 text-center">
          <h2 className="mb-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Upload Resumes for AI Analysis
          </h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Drop your resume files and let our AI extract skills, experience, and
            generate match scores instantly.
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-2">
          <Card
            className={`relative flex min-h-64 flex-col items-center justify-center rounded-xl border-2 border-dashed p-8 transition-all ${isDragOver
              ? "border-primary bg-primary/5"
              : "border-border bg-card hover:border-primary/50"
              }`}
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragOver(true);
            }}
            onDragLeave={() => setIsDragOver(false)}
            onDrop={handleDrop}
          >
            <div className="flex flex-col items-center text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <Upload className="h-8 w-8 text-primary" />
              </div>
              <h3 className="mb-2 text-lg font-semibold text-foreground">
                Drag and drop resumes here
              </h3>
              <p className="mb-4 text-sm text-muted-foreground">
                Support for PDF, DOC, DOCX files up to 10MB
              </p>
              <label>
                <input
                  type="file"
                  className="hidden"
                  accept=".pdf,.doc,.docx"
                  multiple
                  onChange={handleFileSelect}
                />
                <Button
                  variant="outline"
                  className="cursor-pointer border-border text-foreground hover:bg-secondary bg-transparent"
                  asChild
                >
                  <span>Browse Files</span>
                </Button>
              </label>
            </div>
          </Card>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-foreground">
                Uploaded Files
              </h3>
              {uploadedFiles.length > 0 && (
                <span className="text-sm text-muted-foreground">
                  {uploadedFiles.filter((f) => f.status === "complete").length} of{" "}
                  {uploadedFiles.length} analyzed
                </span>
              )}
            </div>

            {uploadedFiles.length === 0 ? (
              <Card className="flex min-h-52 flex-col items-center justify-center rounded-xl border border-border bg-card p-8 text-center">
                <FileText className="mb-4 h-12 w-12 text-muted-foreground/50" />
                <p className="text-sm text-muted-foreground">
                  No files uploaded yet. Drop files or click browse to get
                  started.
                </p>
              </Card>
            ) : (
              <div className="max-h-64 space-y-3 overflow-y-auto">
                {uploadedFiles.map((file) => (
                  <Card
                    key={file.name}
                    className="flex items-center gap-4 rounded-lg border border-border bg-card p-4"
                  >
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                      <FileText className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="truncate text-sm font-medium text-foreground">
                        {file.name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {formatSize(file.size)}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {file.status === "uploading" && (
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Loader2 className="h-4 w-4 animate-spin" />
                          <span className="text-xs">Uploading...</span>
                        </div>
                      )}
                      {file.status === "analyzing" && (
                        <div className="flex items-center gap-2 text-primary">
                          <Sparkles className="h-4 w-4 animate-pulse" />
                          <span className="text-xs">Analyzing...</span>
                        </div>
                      )}
                      {file.status === "complete" && (
                        <div className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-accent" />
                          <span className="text-sm font-semibold text-accent">
                            {file.score}%
                          </span>
                        </div>
                      )}
                      <button
                        onClick={() => removeFile(file.name)}
                        className="rounded-full p-1 text-muted-foreground hover:bg-secondary hover:text-foreground"
                        aria-label="Remove file"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  </Card>
                ))}
              </div>
            )}

            {uploadedFiles.filter((f) => f.status === "complete").length > 0 && (
              <Button
                onClick={() => document.getElementById("dashboard")?.scrollIntoView({ behavior: "smooth" })}
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
              >
                View Full Analysis
              </Button>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
