"use client";

import { useData } from "@/components/data-provider";
import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles, Zap, Target, BarChart3, FileText, CheckCircle, Brain, Clock } from "lucide-react";
import { useEffect, useState } from "react";

const stats = [
  { value: "10K+", label: "Resumes Processed", icon: FileText },
  { value: "95%", label: "Match Accuracy", icon: CheckCircle },
  { value: "50+", label: "Skills Tracked", icon: Brain },
  { value: "2.5s", label: "Avg. Screening Time", icon: Clock },
];

const features = [
  { icon: Zap, label: "Lightning Fast" },
  { icon: Target, label: "Precise Matching" },
  { icon: BarChart3, label: "Deep Analytics" },
];

export function HeroSection() {
  const [animatedValue, setAnimatedValue] = useState(0);
  const { userRole } = useData();

  useEffect(() => {
    const interval = setInterval(() => {
      setAnimatedValue((prev) => (prev >= 95 ? 95 : prev + 1));
    }, 20);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative overflow-hidden border-b border-border bg-background px-4 py-16 sm:px-6 sm:py-24">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="/hero-bg.png"
          alt="Background pattern"
          className="h-full w-full object-cover opacity-80 dark:opacity-30 transition-opacity"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/60 to-transparent" />
      </div>

      {/* Decorative blobs (kept but adjusted z-index) */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute -left-1/4 top-0 h-96 w-96 rounded-full bg-primary/10 blur-3xl" />
        <div className="absolute -right-1/4 bottom-0 h-96 w-96 rounded-full bg-accent/10 blur-3xl" />
      </div>

      <div className="relative z-10 mx-auto max-w-7xl">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-8">
          <div className="flex flex-col justify-center">
            <div className="mb-6 flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                <Sparkles className="h-3 w-3" />
                AI-Powered Hiring
              </span>
            </div>

            <h1 className="mb-6 text-5xl font-extrabold leading-tight tracking-tight text-foreground sm:text-6xl lg:text-7xl text-balance drop-shadow-sm">
              Screen Resumes with{" "}
              <span className="text-primary bg-clip-text text-transparent bg-gradient-to-r from-primary to-blue-600">AI Precision</span>
            </h1>

            <p className="mb-8 max-w-lg text-lg leading-relaxed text-muted-foreground text-pretty">
              Transform your hiring process with intelligent resume screening,
              skill extraction, and job matching. Find the perfect candidates in
              seconds, not hours.
            </p>

            <div className="mb-10 flex flex-wrap items-center gap-4">
              {userRole === "student" && (
                <Button
                  size="lg"
                  className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
                  onClick={() => {
                    const element = document.getElementById('upload');
                    if (element) {
                      element.scrollIntoView({ behavior: 'smooth' });
                    }
                  }}
                >
                  Start Screening
                  <ArrowRight className="h-4 w-4" />
                </Button>
              )}
              <Button
                size="lg"
                variant="outline"
                className="border-border text-foreground hover:bg-secondary bg-transparent"
                onClick={() => {
                  // Scroll to dashboard
                  const element = document.getElementById('dashboard');
                  if (element) {
                    element.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
              >
                View Demo
              </Button>
            </div>

            <div className="flex flex-wrap items-center gap-6">
              {features.map((feature) => (
                <div
                  key={feature.label}
                  className="flex items-center gap-2 rounded-full border border-border/50 bg-background/50 px-4 py-2 text-sm font-medium text-foreground shadow-sm backdrop-blur-sm transition-transform hover:scale-105"
                >
                  <feature.icon className="h-4 w-4 text-primary" />
                  {feature.label}
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-center lg:justify-end">
            <div className="w-full max-w-md space-y-4">
              <div className="rounded-xl border border-white/10 bg-gradient-to-br from-white/5 to-white/0 p-6 backdrop-blur-md shadow-xl">
                <div className="mb-4 flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">
                    AI Match Score
                  </span>
                  <span className="text-2xl font-bold text-primary">
                    {animatedValue}%
                  </span>
                </div>
                <div className="h-3 w-full overflow-hidden rounded-full bg-secondary/50">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-primary to-accent"
                    style={{ width: `${animatedValue}%` }}
                  />
                </div>
                <p className="mt-3 text-xs text-muted-foreground">
                  Based on 15 matching criteria
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {stats.map((stat) => (
                  <div
                    key={stat.label}
                    className="group relative overflow-hidden rounded-xl border border-white/10 bg-white/5 p-4 text-center backdrop-blur-md transition-all hover:bg-white/10 hover:shadow-lg hover:-translate-y-1"
                  >
                    <div className="mb-2 flex justify-center">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/20 text-primary transition-transform group-hover:scale-110">
                        <stat.icon className="h-4 w-4" />
                      </div>
                    </div>
                    <div className="text-2xl font-bold text-foreground">
                      {stat.value}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {stat.label}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
