import { Header } from "@/components/header";
import { HeroSection } from "@/components/hero-section";
import { UploadSection } from "@/components/upload-section";
import { SkillsDashboard } from "@/components/skills-dashboard";
import { JobMatching } from "@/components/job-matching";
import { CandidatesSection } from "@/components/candidates-section";
import { Footer } from "@/components/footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <HeroSection />
        <UploadSection />
        <SkillsDashboard />
        <JobMatching />
        <CandidatesSection />
      </main>
      <Footer />
    </div>
  );
}
